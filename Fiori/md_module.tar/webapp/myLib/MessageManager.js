sap.ui.define([
    "sap/m/MessageBox",
    "student27/sap/training/mdmodule/myLib/Formatter"
], function(MessageBox, Formatter) {
    return {
         
    }
});