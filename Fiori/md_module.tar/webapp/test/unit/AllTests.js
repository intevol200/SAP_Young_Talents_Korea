sap.ui.define([
	"student27sap.training./md_module/test/unit/controller/View1.controller"
], function () {
	"use strict";
});
