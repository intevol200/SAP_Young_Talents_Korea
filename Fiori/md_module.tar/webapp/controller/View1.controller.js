sap.ui.define([
    "sap/ui/core/mvc/Controller",
    "sap/m/MessageBox"
],
	/**
	 * @param {typeof sap.ui.core.mvc.Controller} Controller
	 */
	function (Controller, MessageBox) {
		"use strict";

		return Controller.extend("student27.sap.training.mdmodule.controller.View1", {
			onInit: function () {

            },
            reportSuccess : function(sMsg, sTitle) {
                MessageBox.show (
                    Msg.charAt(0).toUpperCase() + sValue.slice(1), {
                        title: sTitle.charAt(0).toUpperCase() + sValue.slice(1)
                    }
                );
            }

            var oButton = new sap.m.MessageBox
            var sAAA = oButton.
		});
	});
